/*
 * Function.h
 *
 *  Created on: Apr. 7, 2021
 *      Author: tina
 */
#include <Servo.h>
#include <SD.h>
#include <SPI.h>

#ifndef FUNCTION_H
extern "C" {
  #define FUNCTION_H_

  int measure();
  
  float convert(int volt_analog);
  
  bool ThresholdTemp(float temp);
  
  bool accessState();
  
  void redLED(bool thresh, int pinNumber);
  
  void catchSlide(int pinNumber);
  
  void blinkBlue(int pinNumber);
  
  void pos(int layer, Servo servo1, Servo servo2, Servo servo3, Servo servo4, Servo servo5, Servo servo6, Servo servo7, int col_count);
  
  void tempLog(long milli, float temperature, File tempFile);
  
  void vaccineLog(int vacc_out, int total, long milli, File vaccFile);

  int vaccine_out(int vacc_in, int total, int col);
  
  int rot(int vacc_out, int col);

  bool layerEmpty(int col_count);

  bool catchFull(int rotation);

  void blueLED(bool full, int pinNumber);
}

#endif /* FUNCTION_H_ */
